import os
import numpy as np

outlist = '/home/mircea/Desktop/TimeCycle-master/YOUR_DATASET_FOLDER/davis/DAVIS/vallist.txt'
imgfolder = '/home/mircea/Desktop/TimeCycle-master/YOUR_DATASET_FOLDER/davis/DAVIS/JPEGImages/Full-Resolution/'
lblfolder = '/home/mircea/Desktop/TimeCycle-master/YOUR_DATASET_FOLDER/davis/DAVIS/Full-Resolution/'

jpglist = []

f1 = open('/home/mircea/Desktop/TimeCycle-master/YOUR_DATASET_FOLDER/davis/DAVIS/ImageSets/2017/test-dev.txt', 'r')
for line in f1:
    line = line[:-1]
    jpglist.append(line)
f1.close()


f = open(outlist, 'w')

for i in range(len(jpglist)):

    fname = jpglist[i]
    fnameim = imgfolder + fname + '/'
    fnamelbl= lblfolder + fname + '/'

    print(len(os.listdir(fnameim)) )

    if len(os.listdir(fnameim)) > 20:

        f.write(fnameim + ' ' + fnamelbl + '\n')


f.close()
